#Once you determine the tax rate, compute income tax to be adjusted gross income times tax rate. If the income tax is less than 0, set the income tax to $100. 

Lastname = input("Enter Lastname: ")
Dep = input("Enter Numbers of Dependents: ")
Gross = float(input("Enter Gross Income: $"))

AdGross = float(Gross) - (12000 * float(Dep))

if AdGross > 50000.00:
  Tax = .20
else:
  Tax = .10

IncomeTax = AdGross * Tax

if IncomeTax < 0:
  IncomeTax = 100

print(Lastname,":")
print("Gross Income: $",Gross)
print("Number of Dependents: ",Dep)
print("Adjusted Gross Income: $",AdGross)
print("Income Tax: $",IncomeTax)
