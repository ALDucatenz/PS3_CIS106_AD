#Display the order total and shipping charge 

Books = float(input("Number of Books Orders: "))
Cost = float(input("Cost per Book: $"))

Order = Cost * Books

if Order > 50.00:
  Ship = 0
else:
  Ship = 25.00

Total = Order + Ship

print("Order Total: $", Total)
print("Shipping Charge: $",Ship)