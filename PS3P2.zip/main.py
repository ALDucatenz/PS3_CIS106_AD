#Compute the extended price to be quantity x unit price.
item = input("Enter an item to purchase (A or B): ")
qty = float(input("Enter quantity of order: "))

if item == "A" :
  up = 10.00
else:
  up = 20.00

ext = qty * up

print("Item ordered:", item)
print("Unit price: $", up)
print("Extended price: $", ext)