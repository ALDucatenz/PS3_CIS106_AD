#The total is computed as extended price plus the tax. Display the quantity, unit price, extended price, tax and total. 

qty = float(input("Please enter the quantity to order: "))

if qty >= 1000:
 up = 3.00
else:
 up = 5.00

ext = qty * up 
tax = ext * 0.07
total = ext + tax

print("Quantity Order:", qty)
print("Unit price: $", up)
print("Extended price: $", ext)
print("Tax price: $", tax)
print("Total price: $", total)