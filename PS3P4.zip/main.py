#Display name and cost of appliance, the cost of the warrantee and the total (cost of the appliance + warranty).

Name = input("Appliance Name: ")
Cost = float(input("Cost of Appliance: $"))

if Cost > 1000:
  Warr = float(Cost) * .10
else:
  Warr = float(Cost) * .05

Total = Cost + Warr

print(Name,": $",Cost)
print("Warranty of",Name,": $",Warr)
print("Total Cost of",Name,": $",Total)